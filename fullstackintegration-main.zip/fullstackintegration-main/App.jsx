import React from 'react'
import ProductList from './components/ProductList'

export default function App(){
  return (
    <div className="app">
      <h1>Products</h1>
      <ProductList />
    </div>
  )
}
