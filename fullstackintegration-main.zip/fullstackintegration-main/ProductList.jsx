import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function ProductList(){
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const source = axios.CancelToken.source()

    async function fetchProducts(){
      try{
        setLoading(true)
        setError(null)
        const res = await axios.get('http://localhost:4000/api/products', {
          cancelToken: source.token,
          headers: { 'Accept': 'application/json' }
        })
        setProducts(res.data)
      }catch(err){
        if(axios.isCancel(err)) return
        setError(err.message || 'Failed to fetch')
      }finally{
        setLoading(false)
      }
    }

    fetchProducts()

    return () => source.cancel('Component unmounted')
  }, [])

  if(loading) return <p>Loading products...</p>
  if(error) return <p style={{color:'red'}}>Error: {error}</p>

  return (
    <div className="product-list">
      {products.length === 0 ? (
        <p>No products available.</p>
      ) : (
        <ul>
          {products.map(p => (
            <li key={p.id} style={{margin: '8px 0'}}>
              <strong>{p.name}</strong> — ${p.price}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
