# Products Fullstack Example

This workspace contains a simple Express API (backend) and a React frontend (Vite) that fetches products via Axios.

Backend (port 4000):
- Folder: `backend`
- Run:
  - npm install
  - npm run dev (requires nodemon) or npm start
- API endpoint: GET http://localhost:4000/api/products

Frontend (port 3000):
- Folder: `frontend`
- Run:
  - npm install
  - npm run dev

Tips:
- Run backend first, then frontend.
- If CORS or port issues occur, ensure backend is running on port 4000 and frontend on 3000.
